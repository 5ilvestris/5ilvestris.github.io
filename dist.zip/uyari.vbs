Do
x=msgbox("     Kutuphane Bilgisayarlarinda Oyun Oynamak Yasaktir   " & vbNewLine & "                        Bilgisayar Kapatilacaktir" ,16, "                                                    UYARI")
Loop